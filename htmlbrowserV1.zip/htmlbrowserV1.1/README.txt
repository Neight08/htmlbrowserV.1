README

to start htmlbrowser on chrome os simply right click on htmlbroser.html and click view.
once inside place your full url in the text box and hit go from there your website will load.